package entity.Item;

public interface ItemFactory {
    Item createItem();
}