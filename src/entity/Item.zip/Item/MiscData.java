package entity.Item;

import java.util.List;
import java.util.stream.Collectors;

public class MiscData {

    public static final List<ItemFactory> ALL_MISC_FACTORIES = List.of(
            (ItemFactory) () -> new FuelItem("Coal", 40.0, 20.0, 2),
            (ItemFactory) () -> new FuelItem("Firewood", 20.0, 10.0, 1),

            (ItemFactory) () -> new MiscItem("Eggplant", 50.0, 0),
            (ItemFactory) () -> new MiscItem("Fish n’ Chips Recipe", 250.0, 0),
            (ItemFactory) () -> new MiscItem("Fish Sandwich Recipe", 250.0, 0)
    );

    public static List<Item> getAllMiscItems() {
        return ALL_MISC_FACTORIES.stream()
                .map(ItemFactory::createItem)
                .collect(Collectors.toList());
    }

    private MiscData() {}
}