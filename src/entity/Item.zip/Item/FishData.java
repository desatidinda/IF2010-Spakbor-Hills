package entity.Item;

import entity.Farm.Season;
import entity.Farm.Weather;
import java.util.List;
import java.util.stream.Collectors;

import entity.Item.ItemFactory;

public class FishData {
    public static final List<ItemFactory> ALL_FISH_FACTORIES = List.of(
// ########################################## COMMON FISH ##########################################
            (ItemFactory) () -> new Fish("Bullhead", FishType.COMMON,
                    List.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER),
                    "00:00-23:59", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Mountain Lake")),

            (ItemFactory) () -> new Fish("Carp", FishType.COMMON,
                    List.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER),
                    "00:00-23:59", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Mountain Lake", "Pond")),

            (ItemFactory) () -> new Fish("Chub", FishType.COMMON,
                    List.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER),
                    "00:00-23:59", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Forest River", "Mountain Lake")),

// ########################################## REGULAR FISH ##########################################
            (ItemFactory) () -> new Fish("Halibut", FishType.REGULAR,
                    List.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER),
                    "06:00-11:00,19:00-02:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Ocean")),

            (ItemFactory) () -> new Fish("Catfish", FishType.REGULAR,
                    List.of(Season.SPRING, Season.SUMMER, Season.FALL),
                    "06:00-22:00", List.of(Weather.RAINY),
                    List.of("Forest River", "Pond")),

            (ItemFactory) () -> new Fish("Flounder", FishType.REGULAR,
                    List.of(Season.SPRING, Season.SUMMER),
                    "06:00-22:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Ocean")),

            (ItemFactory) () -> new Fish("Large Mouth Bass", FishType.REGULAR,
                    List.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER),
                    "06:00-18:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Mountain Lake")),

            (ItemFactory) () -> new Fish("Rainbow Trout", FishType.REGULAR,
                    List.of(Season.SUMMER),
                    "06:00-18:00", List.of(Weather.SUNNY),
                    List.of("Forest River", "Mountain Lake")),

            (ItemFactory) () -> new Fish("Sturgeon", FishType.REGULAR,
                    List.of(Season.SUMMER, Season.WINTER),
                    "06:00-18:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Mountain Lake")),

            (ItemFactory) () -> new Fish("Midnight Carp", FishType.REGULAR,
                    List.of(Season.WINTER, Season.FALL),
                    "20:00-02:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Mountain Lake", "Pond")),

            (ItemFactory) () -> new Fish("Octopus", FishType.REGULAR,
                    List.of(Season.SUMMER),
                    "06:00-22:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Ocean")),

            (ItemFactory) () -> new Fish("Pufferfish", FishType.REGULAR,
                    List.of(Season.SUMMER),
                    "00:00-16:00", List.of(Weather.SUNNY),
                    List.of("Ocean")),

            (ItemFactory) () -> new Fish("Sardine", FishType.REGULAR,
                    List.of(Season.SPRING, Season.SUMMER, Season.FALL, Season.WINTER),
                    "06:00-18:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Ocean")),

            (ItemFactory) () -> new Fish("Super Cucumber", FishType.REGULAR,
                    List.of(Season.SUMMER, Season.FALL, Season.WINTER),
                    "18:00-02:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Ocean")),

            (ItemFactory) () -> new Fish("Salmon", FishType.REGULAR,
                    List.of(Season.FALL),
                    "06:00-18:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Forest River")),

// ########################################## LEGENDARY FISH ##########################################
            (ItemFactory) () -> new Fish("Legend", FishType.LEGENDARY,
                    List.of(Season.SPRING),
                    "08:00-20:00", List.of(Weather.RAINY),
                    List.of("Mountain Lake")),

            (ItemFactory) () -> new Fish("Angler", FishType.LEGENDARY,
                    List.of(Season.FALL),
                    "08:00-20:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Pond")),

            (ItemFactory) () -> new Fish("Crimsonfish", FishType.LEGENDARY,
                    List.of(Season.SUMMER),
                    "08:00-20:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Ocean")),

            (ItemFactory) () -> new Fish("Glacierfish", FishType.LEGENDARY,
                    List.of(Season.WINTER),
                    "08:00-20:00", List.of(Weather.SUNNY, Weather.RAINY),
                    List.of("Forest River"))
    );
    public static List<Fish> getAllFish() {
        return ALL_FISH_FACTORIES.stream()
                .map(factory -> (Fish) factory.createItem())
                .collect(Collectors.toList());
    }

    private FishData() {}
}
