package entity.Item;

import entity.Item.Item;

public class MiscItem extends Item {
    public MiscItem(String itemName, double buyPrice, double sellPrice) {
        super(itemName, buyPrice, sellPrice);
    }

    @Override
    public String getCategory() {
        return "Misc";
    }
}