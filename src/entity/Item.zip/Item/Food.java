package entity.Item;

public class Food extends Item {
    private int energyRestored;

    public Food(String itemName, Double buyPrice, double sellPrice, int energyRestored) {
        super(itemName, buyPrice, sellPrice);
        this.energyRestored = energyRestored;
    }

    @Override
    public String getCategory() {
        return "Food";
    }
}