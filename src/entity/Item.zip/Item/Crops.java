package entity.Item;

public class Crops extends Item{
    
    public Crops(String itemName,double buyPrice, double sellPrice){
        super(itemName, buyPrice, sellPrice);
    }

    @Override
    public String getCategory() {
        return "Crops";
    }
}