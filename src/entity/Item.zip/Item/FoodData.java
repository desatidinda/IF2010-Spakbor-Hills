package entity.Item;

import java.util.List;
import java.util.stream.Collectors;

public class FoodData {

    public static final List<ItemFactory> ALL_FOOD_FACTORIES = List.of(
            (ItemFactory) () -> new Food("Fish n’ Chips", 150.0, 135.0, 50),
            (ItemFactory) () -> new Food("Baguette", 100.0, 80.0, 25),
            (ItemFactory) () -> new Food("Sashimi", 300.0, 275.0, 70),
            (ItemFactory) () -> new Food("Fugu", -1.0, 135.0, 50), // -1.0 menandakan tidak bisa dibeli
            (ItemFactory) () -> new Food("Wine", 100.0, 90.0, 20),
            (ItemFactory) () -> new Food("Pumpkin Pie", 120.0, 100.0, 35),
            (ItemFactory) () -> new Food("Veggie Soup", 140.0, 120.0, 40),
            (ItemFactory) () -> new Food("Fish Stew", 280.0, 260.0, 70),
            (ItemFactory) () -> new Food("Spakbor Salad", -1.0, 250.0, 70), // Tidak bisa dibeli
            (ItemFactory) () -> new Food("Fish Sandwich", 200.0, 180.0, 50),
            (ItemFactory) () -> new Food("The Legends of Spakbor", -1.0, 2000.0, 100), // Tidak bisa dibeli
            (ItemFactory) () -> new Food("Cooked Pig's Head", 1000.0, 0.0, 100)
    );

    public static List<Food> getAllFood() {
        return ALL_FOOD_FACTORIES.stream()
                .map(factory -> (Food) factory.createItem())
                .collect(Collectors.toList());
    }

    private FoodData() {}
}