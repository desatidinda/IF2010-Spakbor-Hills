package entity.Item;

import entity.Farm.Season;

public class Seeds extends Item{
    private Season season;
    private int daysToHarvest;

    public Seeds(String itemName, Double buyPrice, Double sellPrice, Season season, int daysToHarvest){
        super(itemName, buyPrice, sellPrice);
        this.season = season;
        this.daysToHarvest = daysToHarvest;
    }

    public Season getSeason() {
        return season;
    }

    public int getDaysToHarvest() {
        return daysToHarvest;
    }

    @Override
    public String getCategory() {
    return "Seeds";
    }
}