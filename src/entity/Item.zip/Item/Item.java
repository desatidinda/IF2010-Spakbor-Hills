package entity.Item;

public abstract class Item {
    protected String itemName;
    protected double buyPrice;
    protected double sellPrice;

    public Item(String itemName, double buyPrice, double sellPrice){
        this.itemName = itemName;
        this.buyPrice = buyPrice;
        this.sellPrice = sellPrice;
    }

    public String getItemName() {
        return itemName;
    }

    public double getBuyPrice() {
        return buyPrice;
    }

    public double getSellPrice() {
        return sellPrice;
    }

    protected void setSellPrice(double sellPrice) {
        this.sellPrice = sellPrice;
    }

    public abstract String getCategory();
}