package entity.Item;

import java.util.List;
import java.util.stream.Collectors;

public class CropsData {

    public static final List<ItemFactory> ALL_CROPS_FACTORIES = List.of(
            // ################ SPRING CROPS ################
            (ItemFactory) () -> new Crops("Parsnip", 0.0, 35.0),
            (ItemFactory) () -> new Crops("Cauliflower", 0.0, 150.0),
            (ItemFactory) () -> new Crops("Potato", 0.0, 80.0),
            (ItemFactory) () -> new Crops("Wheat", 0.0, 30.0),

            // ################ SUMMER CROPS ################
            (ItemFactory) () -> new Crops("Blueberry", 0.0, 40.0),
            (ItemFactory) () -> new Crops("Tomato", 0.0, 60.0),
            (ItemFactory) () -> new Crops("Hot Pepper", 0.0, 25.0),
            (ItemFactory) () -> new Crops("Melon", 0.0, 130.0),

            // ################ FALL CROPS ################
            (ItemFactory) () -> new Crops("Cranberry", 0.0, 45.0),
            (ItemFactory) () -> new Crops("Pumpkin", 0.0, 150.0),
            (ItemFactory) () -> new Crops("Wheat", 0.0, 30.0),
            (ItemFactory) () -> new Crops("Grape", 0.0, 40.0)
    );

    public static List<Crops> getAllCrops() {
        return ALL_CROPS_FACTORIES.stream()
                .map(factory -> (Crops) factory.createItem())
                .collect(Collectors.toList());
    }

    private CropsData() {}
}