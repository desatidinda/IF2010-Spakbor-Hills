package entity.Item;

import java.util.List;
import java.util.stream.Collectors;

import entity.Farm.Season;

public class SeedsData {

    public static final List<ItemFactory> ALL_SEEDS_FACTORIES = List.of(

            // ================= SPRING SEEDS =================
            (ItemFactory) () -> new Seeds("Parsnip Seeds", 20.0, 10.0, Season.SPRING, 1),
            (ItemFactory) () -> new Seeds("Cauliflower Seeds", 80.0, 40.0, Season.SPRING, 5),
            (ItemFactory) () -> new Seeds("Potato Seeds", 50.0, 25.0, Season.SPRING, 3),
            (ItemFactory) () -> new Seeds("Wheat Seeds", 60.0, 30.0, Season.SPRING, 1),

            // ================= SUMMER SEEDS =================
            (ItemFactory) () -> new Seeds("Blueberry Seeds", 80.0, 40.0, Season.SUMMER, 7),
            (ItemFactory) () -> new Seeds("Tomato Seeds", 50.0, 25.0, Season.SUMMER, 3),
            (ItemFactory) () -> new Seeds("Hot Pepper Seeds", 40.0, 20.0, Season.SUMMER, 1),
            (ItemFactory) () -> new Seeds("Melon Seeds", 80.0, 40.0, Season.SUMMER, 4),

            // ================= FALL SEEDS =================
            (ItemFactory) () -> new Seeds("Cranberry Seeds", 100.0, 50.0, Season.FALL, 2),
            (ItemFactory) () -> new Seeds("Pumpkin Seeds", 150.0, 75.0, Season.FALL, 7),
            (ItemFactory) () -> new Seeds("Wheat Seeds", 60.0, 30.0, Season.FALL, 1),
            (ItemFactory) () -> new Seeds("Grape Seeds", 60.0, 30.0, Season.FALL, 3)
    );

    public static List<Seeds> getAllSeeds() {
        return ALL_SEEDS_FACTORIES.stream()
                .map(factory -> (Seeds) factory.createItem())
                .collect(Collectors.toList());
    }
    private SeedsData() {} // prevent instantiation
}
